<?php
require '../db/config.php';

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$resultat = $conn->query("SELECT * FROM config");
$resultat->setFetchMode(PDO::FETCH_OBJ);
if( $config = $resultat->fetch() ) {
    deleteDirectory("../admin/");
    deleteDirectory("../api/");
    deleteDirectory("../notification/");
    deleteDirectory("../password_reset/");
        
    xcopy("AdminPanel", "../");

    //v1.6.5
    xcopy("dumper.php", "../db/dumper.php");
    mkdir("../db/backup");

    //v1.5.5
    /*xcopy("database.php", "../db/database.php");
    $db_file_path2 = "../db/database.php";
    $db_file2 = file_get_contents($db_file_path2);
    $is_installed2 = strpos($db_file2, "enter_hostname");
    if ($is_installed2) {
      $db_file2 = str_replace('enter_hostname', $servername, $db_file2);
      $db_file2 = str_replace('enter_db_username', $username, $db_file2);
      $db_file2 = str_replace('enter_db_password', $password, $db_file2);
      $db_file2 = str_replace('enter_database_name', $dbname, $db_file2);
      file_put_contents($db_file_path2, $db_file2);
    }*/

    $sql ="UPDATE config SET Dashboard_Version=? WHERE id =1";
    $stmt= $conn->prepare($sql);
    $stmt->execute(["1.6.5"]);

    //v1.6.5
    $sql1 ="CREATE TABLE live_tv_genres ( `id` INT NOT NULL AUTO_INCREMENT , `name` TEXT NOT NULL , `icon` TEXT NOT NULL , `featured` INT NOT NULL COMMENT '0=NotFeatured, 1=Featured' , `status` INT NOT NULL COMMENT '0=NotPublished, 1=Published' , PRIMARY KEY (`id`)) ENGINE = InnoDB";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->execute();

    $sql2 ="ALTER TABLE `config` ADD `onscreen_effect` INT NOT NULL COMMENT '0=Nothing, 1=Snow' AFTER `google_login`";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->execute();

    $sql3 ="ALTER TABLE `config` ADD `razorpay_status` INT NOT NULL COMMENT '0=Disabled, 1=Enabled' AFTER `onscreen_effect`";
    $stmt3 = $conn->prepare($sql3);
    $stmt3->execute();

    $sql4 ="ALTER TABLE `config` ADD `razorpay_key_id` TEXT NOT NULL AFTER `razorpay_status`, ADD `razorpay_key_secret` TEXT NOT NULL AFTER `razorpay_key_id`";
    $stmt4 = $conn->prepare($sql4);
    $stmt4->execute();

    $sql5 ="ALTER TABLE `config` ADD `content_item_type` INT NOT NULL DEFAULT '0' COMMENT '0=Default, 1=v2' AFTER `razorpay_key_secret`, ADD `live_tv_content_item_type` INT NOT NULL DEFAULT '0' COMMENT '0=Default, 1=v2' AFTER `content_item_type`";
    $stmt5 = $conn->prepare($sql5);
    $stmt5->execute();

    $sql6 ="CREATE TABLE devices ( `id` INT NOT NULL AUTO_INCREMENT , `device` TEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB";
    $stmt6 = $conn->prepare($sql6);
    $stmt6->execute();

    $sql7 ="CREATE TABLE devices_log ( `id` INT NOT NULL AUTO_INCREMENT , `device_id` INT NOT NULL , `open_date` TEXT NOT NULL , `open_time` TEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB";
    $stmt7 = $conn->prepare($sql7);
    $stmt7->execute();

    $sql8 ="ALTER TABLE `config` ADD `telegram_token` TEXT NOT NULL AFTER `live_tv_content_item_type`, ADD `telegram_chat_id` TEXT NOT NULL AFTER `telegram_token`";
    $stmt8 = $conn->prepare($sql8);
    $stmt8->execute();

    //v1.6.0
    /*$sql1 ="CREATE TABLE request ( id INT NOT NULL AUTO_INCREMENT , user_id INT NOT NULL , title TEXT NOT NULL , description LONGTEXT NOT NULL , type INT NOT NULL COMMENT '0=Custom, 1=Movie, 2=Web Series, 3=Live TV', status INT NOT NULL COMMENT '0=Pending, 1=Accepted , 2=Rejected' , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->execute();*/

    //v1.5.0
    /*$sql1 ="ALTER TABLE coupon ADD COLUMN IF NOT EXISTS expire_date TEXT NOT NULL AFTER used_by";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->execute();

    $sql2 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS AdColony_app_id TEXT NOT NULL AFTER genre_visible_in_home, ADD COLUMN IF NOT EXISTS AdColony_banner_zone_id TEXT NOT NULL AFTER AdColony_app_id, ADD COLUMN IF NOT EXISTS AdColony_interstitial_zone_id TEXT NOT NULL AFTER AdColony_banner_zone_id";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->execute();

    $sql3 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS unity_game_id TEXT NOT NULL AFTER AdColony_interstitial_zone_id, ADD COLUMN IF NOT EXISTS unity_banner_id TEXT NOT NULL AFTER unity_game_id";
    $stmt3 = $conn->prepare($sql3);
    $stmt3->execute();

    $sql4 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS custom_banner_url TEXT NOT NULL AFTER unity_banner_id, ADD COLUMN IF NOT EXISTS custom_banner_click_url_type INT NOT NULL DEFAULT '0' COMMENT '0=nothing 1=External Brawser 2=Internal Brawser' AFTER custom_banner_url, ADD COLUMN IF NOT EXISTS custom_banner_click_url TEXT NOT NULL AFTER custom_banner_click_url_type, ADD COLUMN IF NOT EXISTS custom_interstitial_url TEXT NOT NULL AFTER custom_banner_click_url, ADD COLUMN IF NOT EXISTS custom_interstitial_click_url_type INT NOT NULL DEFAULT '0' COMMENT '0=nothing 1=External Brawser 2=Internal Brawser' AFTER custom_interstitial_url, ADD COLUMN IF NOT EXISTS custom_interstitial_click_url TEXT NOT NULL AFTER custom_interstitial_click_url_type";
    $stmt4 = $conn->prepare($sql4);
    $stmt4->execute();

    $sql5 ="CREATE TABLE IF NOT EXISTS comments ( id INT NOT NULL AUTO_INCREMENT , user_id INT NOT NULL , content_id INT NOT NULL , content_type INT NOT NULL COMMENT '1=Movie, 2=WebSeries' , comment LONGTEXT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt5 = $conn->prepare($sql5);
    $stmt5->execute();

    $sql6 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS movie_comments INT NOT NULL COMMENT '0=Off, 1=On' AFTER custom_interstitial_click_url, ADD COLUMN IF NOT EXISTS webseries_comments INT NOT NULL COMMENT '0=Off, 1=On' AFTER movie_comments";
    $stmt6 = $conn->prepare($sql6);
    $stmt6->execute();

    $sql7 ="CREATE TABLE IF NOT EXISTS subtitles ( id INT NOT NULL AUTO_INCREMENT , content_id INT NOT NULL , content_type INT NOT NULL COMMENT '1=Movie, 2=WebSeries', language TEXT NOT NULL , subtitle_url TEXT NOT NULL , mime_type TEXT NOT NULL, status INT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt7 = $conn->prepare($sql7);
    $stmt7->execute();

    $sql8 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS google_login INT NOT NULL COMMENT '0=Disabled, 1=Enabled' AFTER webseries_comments";
    $stmt8 = $conn->prepare($sql8);
    $stmt8->execute();*/

    /*
    //v1.4.5
    $sql15 ="CREATE TABLE IF NOT EXISTS genres ( id INT NOT NULL AUTO_INCREMENT , name TEXT NOT NULL , icon TEXT NOT NULL , description LONGTEXT NOT NULL , featured INT NOT NULL COMMENT '0=NotFeatured, 1=Featured' , status INT NOT NULL COMMENT ' 0=NotPublished, 1=Published' , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt15 = $conn->prepare($sql15);
    $stmt15->execute();

    $sql16 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS genre_visible_in_home INT NOT NULL DEFAULT '1' COMMENT '0=No, 1=Yes' AFTER admin_panel_language";
    $stmt16 = $conn->prepare($sql16);
    $stmt16->execute();

    $sql17 ="CREATE TABLE IF NOT EXISTS view_log ( id INT NOT NULL AUTO_INCREMENT , user_id TEXT NOT NULL , content_id INT NOT NULL , content_type INT NOT NULL COMMENT '1=Movie, 2=WebSeries' , date TEXT NOT NULL , time TEXT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt17 = $conn->prepare($sql17);
    $stmt17->execute();

    $sql18 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS license_code TEXT NOT NULL AFTER api_key";
    $stmt18 = $conn->prepare($sql18);
    $stmt18->execute();

    //v1.4.0
    $sql11 ="ALTER TABLE user_db CHANGE COLUMN IF EXISTS subscription_start subscription_start TEXT NOT NULL";
    $stmt11 = $conn->prepare($sql11);
    $stmt11->execute();

    $sql12 ="ALTER TABLE user_db CHANGE COLUMN IF EXISTS subscription_exp subscription_exp TEXT NOT NULL";
    $stmt12 = $conn->prepare($sql12);
    $stmt12->execute();


    $sql13 ="ALTER TABLE movie_play_links ADD COLUMN IF NOT EXISTS link_type INT NOT NULL COMMENT '0=NotPremium, 1=Premium' AFTER end_credits_marker";
    $stmt13 = $conn->prepare($sql13);
    $stmt13->execute();

    $sql14 ="CREATE TABLE IF NOT EXISTS episode_download_links ( id INT NOT NULL AUTO_INCREMENT , name TEXT NOT NULL , size TEXT NOT NULL , quality TEXT NOT NULL , link_order INT NOT NULL , episode_id INT NOT NULL , url TEXT NOT NULL , type TEXT NOT NULL , download_type TEXT NOT NULL , status INT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt14 = $conn->prepare($sql14);
    $stmt14->execute();

    //v1.3.5
    $sql8 ="CREATE TABLE IF NOT EXISTS watch_log ( id INT NOT NULL AUTO_INCREMENT, user_id INT NOT NULL, content_id INT NOT NULL, content_type INT NOT NULL COMMENT '0=Movie,1=WebSeries', PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt8 = $conn->prepare($sql8);
    $stmt8->execute();

    $sql9 ="ALTER TABLE favourite CHANGE COLUMN IF EXISTS user_id user_id TEXT NOT NULL";
    $stmt9 = $conn->prepare($sql9);
    $stmt9->execute();

    $sql10 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS tmdb_language TEXT NOT NULL AFTER PrivecyPolicy, ADD COLUMN IF NOT EXISTS admin_panel_language TEXT NOT NULL AFTER tmdb_language";
    $stmt10 = $conn->prepare($sql10);
    $stmt10->execute();

    //v1.3.0
    $sql6 ="CREATE TABLE IF NOT EXISTS report ( id INT NOT NULL AUTO_INCREMENT , user_id INT NOT NULL , title TEXT NOT NULL , description LONGTEXT NOT NULL , report_type INT NOT NULL , status INT NOT NULL COMMENT '0=Pending, 1=Solved, 2=Canceled' , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt6 = $conn->prepare($sql6);
    $stmt6->execute();

    $sql7 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS facebook_app_id TEXT NOT NULL AFTER StartApp_App_ID, ADD COLUMN IF NOT EXISTS facebook_banner_ads_placement_id TEXT NOT NULL AFTER facebook_app_id, ADD COLUMN IF NOT EXISTS facebook_interstitial_ads_placement_id TEXT NOT NULL AFTER facebook_banner_ads_placement_id";
    $stmt7 = $conn->prepare($sql7);
    $stmt7->execute();

    //v1.2.5
    $sql2 ="ALTER TABLE config ADD COLUMN IF NOT EXISTS TermsAndConditions LONGTEXT NOT NULL AFTER LiveTV_Visiable_in_Home, ADD COLUMN IF NOT EXISTS PrivecyPolicy LONGTEXT NOT NULL AFTER TermsAndConditions";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->execute();

    $sql3 ="CREATE TABLE IF NOT EXISTS movie_download_links ( id INT NOT NULL AUTO_INCREMENT , name TEXT NOT NULL , size TEXT NOT NULL , quality TEXT NOT NULL , link_order INT NOT NULL , movie_id INT NOT NULL , url TEXT NOT NULL , type TEXT NOT NULL , download_type TEXT NOT NULL , status INT NOT NULL COMMENT '0=Not Released, 1=Released' , PRIMARY KEY (id)) ENGINE = InnoDB";
    $stmt3 = $conn->prepare($sql3);
    $stmt3->execute();

    $sql4 ="ALTER TABLE movies DROP COLUMN IF EXISTS platform";
    $stmt4 = $conn->prepare($sql4);
    $stmt4->execute();

    $sql5 ="ALTER TABLE web_series DROP COLUMN IF EXISTS platform";
    $stmt5 = $conn->prepare($sql5);
    $stmt5->execute();
    */

    header("Location: ../admin/dashboard_api/logout.php");
    exit();
} else {
    header("Location: ../admin/dashboard_api/logout.php");
    exit();
}



function xcopy($source, $dest, $permissions = 0755)
{
    $sourceHash = hashDirectory($source);
    // Check for symlinks
    if (is_link($source)) {
        return symlink(readlink($source), $dest);
    }

    // Simple copy for a file
    if (is_file($source)) {
        return copy($source, $dest);
    }

    // Make destination directory
    if (!is_dir($dest)) {
        mkdir($dest, $permissions);
    }

    // Loop through the folder
    $dir = dir($source);
    while (false !== $entry = $dir->read()) {
        // Skip pointers
        if ($entry == '.' || $entry == '..') {
            continue;
        }

        // Deep copy directories
        if($sourceHash != hashDirectory($source."/".$entry)){
             xcopy("$source/$entry", "$dest/$entry", $permissions);
        }
    }

    // Clean up
    $dir->close();
    return true;
}

// In case of coping a directory inside itself, there is a need to hash check the directory otherwise and infinite loop of coping is generated

function hashDirectory($directory){
    if (! is_dir($directory)){ return false; }

    $files = array();
    $dir = dir($directory);

    while (false !== ($file = $dir->read())){
        if ($file != '.' and $file != '..') {
            if (is_dir($directory . '/' . $file)) { $files[] = hashDirectory($directory . '/' . $file); }
            else { $files[] = md5_file($directory . '/' . $file); }
        }
    }

    $dir->close();

    return md5(implode('', $files));
}

function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }

    }

    return rmdir($dir);
}

?>