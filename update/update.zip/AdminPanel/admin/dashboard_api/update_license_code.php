<?php
require_once('../../db/database.php');
$conn = Database::getInstance($_SERVER['HTTP_X_API_KEY']);


if ($_SERVER['REQUEST_METHOD'] === 'POST' && $conn != null) {
    $Body_Json =  file_get_contents('php://input');
    $Json_data = $obj = json_decode($Body_Json);

            function SQLSafe(string $s): string {
                $NewData = stripslashes($s);
                return addslashes($NewData);
            }

            $license_code = SQLSafe($Json_data->license_code);
            if($license_code == "") {
                $sql ="UPDATE config SET license_code =? WHERE id =1";
                $stmt= $conn->prepare($sql);
                $stmt->execute([$license_code]);
                echo "License Updated successfully";
            } else {
                if(!verify($license_code)) {
                    $sql ="UPDATE config SET license_code =? WHERE id =1";
                    $stmt= $conn->prepare($sql);
                    $stmt->execute([$license_code]);
                    echo "License Updated successfully";
                } else {
                    echo "Invalid purchase code";
                } 
            }
            
    
} else  {
    header("HTTP/1.1 401 Unauthorized");
}



function verify($license_code) {
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://cloud.team-dooo.com/Dooo/verify/?code=$license_code",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_SSL_VERIFYHOST => 0,
      CURLOPT_SSL_VERIFYPEER => 0,
      CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache"
      ),
    ));
    
    $response = curl_exec($curl);
    $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        return true;
    } else {
        if(!is_valid_json($response)) {
            $_dj = json_decode($response);
            if($_dj->License != "" || $_dj->License != null) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }
}

function is_valid_json( $raw_json ){
    return ( json_decode( $raw_json , true ) == NULL ) ? true : false ;
}



?>